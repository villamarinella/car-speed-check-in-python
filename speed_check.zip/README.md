Simple programm to measure the car speed between two gates

script is in python 2.7
tested on Ubuntu 14.04 and Raspian wheezy
On Raspberry Pi install uv4l from here:
http://www.linux-projects.org/uv4l/installation/

prepare the system if not intalled already:
sudo apt-get install python-opencv opencv-dev python-numpy python-dev

check you must have: ls -l /dev/video0

You will find:

lr.mp4                  the video for testing
speed_video.py   working with videos
speed_usb.py      working with usb camera
speed_pi.py         working wit Pi and raspicam

Try to understand with python speed_video.py

For Your belongings change the code lines I have prepared with "##"

Yes, I know, the code is terrible, but it works:-)
form follows function:-)

Stay lucky

Klaus Werner
